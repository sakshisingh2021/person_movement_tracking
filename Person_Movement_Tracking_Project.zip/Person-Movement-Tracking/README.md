# Person Movement Tracking & Dot Trajectory Visualization

A computer-vision assignment that detects people in a video, tracks them across frames, and displays each tracked person as a colored dot on a black background. Each person's movement trail is drawn over time.

## Features
- Person detection using YOLO (Ultralytics)
- Multi-object tracking with ByteTrack IDs
- Black-background visualization with colored dots
- Trajectory trails for each person
- Last known dot remains visible during short detection gaps
- No pose estimation and no speed estimation

## Requirements
- Python 3.9–3.12 recommended
- OpenCV
- Ultralytics YOLO
- NumPy

## Setup

```bash
python -m venv .venv
```

Activate it:

**Windows**
```bash
.venv\Scripts\activate
```

**macOS/Linux**
```bash
source .venv/bin/activate
```

Install packages:

```bash
pip install -r requirements.txt
```

The first run downloads the small YOLO model (`yolov8n.pt`) automatically if it is not already available.

## Run

Place your video in this folder, then run:

```bash
python main.py --input input_video.mp4 --output output_tracking.mp4
```

Optional parameters:

```bash
python main.py --input input_video.mp4 --output output_tracking.mp4 --conf 0.4 --trail 100 --max-missed 45
```

- `--conf`: person detection confidence (default 0.35)
- `--trail`: maximum number of trajectory points per person (default 80)
- `--max-missed`: frames to keep the last known dot after a missed detection (default 45)
- `--model`: YOLO model file (default `yolov8n.pt`)
- `--canvas-width`, `--canvas-height`: output visualization dimensions

## How it works
1. Open the video and read it frame by frame.
2. YOLO detects the `person` class.
3. ByteTrack assigns/maintains a tracking ID for each person.
4. The bottom-center of each person's bounding box is mapped to the output canvas.
5. A colored dot and its trajectory are drawn on a black background.
6. If a detection is temporarily missed, the last known dot remains visible for the configured number of frames.
7. The visualization is saved as an MP4 video.

## Project structure

```text
Person-Movement-Tracking/
├── main.py
├── requirements.txt
├── README.md
└── .gitignore
```

## Limitations
- Tracking IDs may change if a person is hidden for a long time or leaves the scene.
- The dot represents the bottom-center of the detected bounding box, not a pose/keypoint.
- This project does not estimate pose or movement speed.
